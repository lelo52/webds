$(function() {

    $(".main > li").mouseover(function() {
        $(this).find(".sub").stop().slideDown(200);
    });

    
    $(".main > li").mouseout(function() {
        $(this).find(".sub").stop().slideUp(200);
    });

    
    
});