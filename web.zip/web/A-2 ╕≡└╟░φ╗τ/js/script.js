$(function() {
    $(".main").mouseover(function(){
        $(".sub").stop().slideDown();
        $(".bg").stop().slideDown();
    });

    $(".main").mouseout(function(){
        $(".sub").stop().slideUp();
        $(".bg").stop().slideUp();
    });

    setInterval(function() {
        $(".slide ul").animate({marginLeft: -1200}, 2000, function() {
            $(".slide li").eq(0).appendTo($(".slide ul"));
            $(".slide ul").css({marginLeft: 0});
        });
    },3000);

    $(".layerPopup").click(function() {
        $(".layer").show();
        $(".popup").show();

        $(".popup a").click(function() {
            $(".layer").hide();
            $(".popup").hide();
        });
    });
});